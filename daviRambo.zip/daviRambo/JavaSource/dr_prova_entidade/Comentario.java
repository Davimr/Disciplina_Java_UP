package dr_prova_entidade;

import java.util.Date;

import javax.faces.annotation.InitParameterMap;
import javax.jws.soap.InitParam;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.ws.rs.DefaultValue;

import org.hibernate.validator.constraints.Length;

import com.oracle.jrockit.jfr.ValueDefinition;




@Entity
@Table(name = "PRV_ENT_COMENTARIO")
public class Comentario {

	
	@Id
	@NotNull
	@Column(name = "PRV_ENT_COMENTARIO_PK")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "NUM_SEQ_COMENTARIO")
	@SequenceGenerator(name = "NUM_SEQ_COMENTARIO", sequenceName = "NUM_SEQ_COMENTARIO", allocationSize = 0)
	private Integer id;
	
	@Column(name = "PRV_ENT_COMENTARIO_NOME")
	@NotBlank
	private String nomePessoa;
	
	@Column(name = "PRV_ENT_COMENTARIO_TEXTO")
	@NotNull
	@Length(min = 10, max = 140)
	private String textoComentario;
	
	@Column(name = "PRV_ENT_COMENTARIO_TIPO")
	@NotNull
	private String tipoMensagem;
	
	@Column(name = "PRV_ENT_COMENTARIO_CURTIDAS")
	private Integer numeroCurtidas;
	
	@Column(name = "PRV_ENT_COMENTARIO_DATAHORA")
	private Date dataHora;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNomePessoa() {
		return nomePessoa;
	}

	public void setNomePessoa(String nomePessoa) {
		this.nomePessoa = nomePessoa;
	}

	public String getTextoComentario() {
		return textoComentario;
	}

	public void setTextoComentario(String textoComentario) {
		this.textoComentario = textoComentario;
	}

	public String getTipoMensagem() {
		return tipoMensagem;
	}

	public void setTipoMensagem(String tipoMensagem) {
		this.tipoMensagem = tipoMensagem;
	}

	public Integer getNumeroCurtidas() {
		return numeroCurtidas;
	}

	public void setNumeroCurtidas(Integer numeroCurtidas) {
		this.numeroCurtidas = numeroCurtidas;
	}

	public Date getDataHora() {
		return dataHora;
	}

	public void setDataHora(Date dataHora) {
		this.dataHora = dataHora;
	}
	
	
	
}
