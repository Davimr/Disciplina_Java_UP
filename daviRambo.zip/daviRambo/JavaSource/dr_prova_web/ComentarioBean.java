package dr_prova_web;

import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;

import dr_prova_entidade.Comentario;
import dr_prova_modelo.ServicoComentario;

@Named
@RequestScoped
public class ComentarioBean  {

	private Comentario comentario;
	
	private List<Comentario> comentarios;
	
	public List<Comentario> getComentarios() {
		comentarios = this.servicocomentario.Listar();
		return comentarios;
	}

	@EJB
	private ServicoComentario servicocomentario;
	
	public ComentarioBean() {
		this.comentario = new Comentario();
	}
	
	public void salvarComentario() {
		this.comentario.setDataHora(new Date());
		Integer numero = 0;
		this.comentario.setNumeroCurtidas(numero);
		this.servicocomentario.cadastrarComentario(this.comentario);
		comentario = new Comentario();	
	}
	
	public void curtirComentario(Comentario comentu) {
		this.servicocomentario.curtir(comentu);
	}
	
	public List<Comentario> ListarComentarios(){
		comentarios = this.servicocomentario.Listar();
		return comentarios;
	}
	
	public void excluirComentario(Comentario coment){
		try {
			this.servicocomentario.excluirComentario(coment);
		} catch (Exception e) {
			FacesMessage m = new FacesMessage();
			m.setSummary(e.getMessage());
			FacesContext.getCurrentInstance().addMessage(null, m);
		}	
	}

	public Comentario getComentario() {
		return comentario;
	}

	public void setComentario(Comentario comentario) {
		this.comentario = comentario;
	}
	
	
}
