package dr_prova_modelo;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import dr_prova_entidade.Comentario;

@Stateless
public class ServicoComentario {
	
	@PersistenceContext
	private EntityManager em;
	
	public void cadastrarComentario(Comentario comentario) {
		this.em.persist(comentario);
	}
	
	public List<Comentario> Listar(){
		return this.em.createQuery("SELECT v FROM Comentario v", Comentario.class).getResultList();
	}
	
	public void excluirComentario(Comentario comentario) throws Exception{
		
		if ( comentario.getNumeroCurtidas() == 0 && comentario.getTipoMensagem().equals("normal")) {
			this.em.remove(this.em.merge(comentario));
		} else {
			throw new Exception("S� pode ser deletado se n�o houverem curtidas e o comentario for do tipo normal.");
		}
	}
	
	public void curtir(Comentario coment) {
		Integer curtidas = coment.getNumeroCurtidas();
		curtidas ++;
		coment.setNumeroCurtidas(curtidas);
		this.em.merge(coment);
	}
}
